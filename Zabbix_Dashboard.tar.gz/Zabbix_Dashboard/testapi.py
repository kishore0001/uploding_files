import requests

def find_zabbix_api_url(base_ip):
    """
    Automatically detect the correct Zabbix API URL
    """
    print(f"🔍 Testing possible API endpoints for {base_ip}...\n")
    
    # Possible URL combinations
    test_urls = [
        f'http://{base_ip}/api_jsonrpc.php',
        f'http://{base_ip}/Iops/api_jsonrpc.php',
        f'http://{base_ip}:8080/api_jsonrpc.php',
        f'http://{base_ip}:8080/Iops/api_jsonrpc.php',
        f'http://{base_ip}:80/api_jsonrpc.php',
        f'http://{base_ip}:80/Iops/api_jsonrpc.php',
        f'https://{base_ip}/api_jsonrpc.php',
        f'https://{base_ip}/zabbix/api_jsonrpc.php',
    ]
    
    # Test payload to check API version
    test_payload = {
        "jsonrpc": "2.0",
        "method": "apiinfo.version",
        "params": {},
        "id": 1
    }
    
    for url in test_urls:
        try:
            print(f"Testing: {url} ... ", end='')
            response = requests.post(
                url,
                json=test_payload,
                headers={'Content-Type': 'application/json-rpc'},
                timeout=5,
                verify=False  # For self-signed SSL certificates
            )
            
            if response.status_code == 200:
                result = response.json()
                if 'result' in result:
                    version = result['result']
                    print(f"✅ SUCCESS! (Zabbix {version})")
                    return url, version
                else:
                    print(f"⚠️  Status 200 but unexpected response")
            else:
                print(f"❌ Status {response.status_code}")
                
        except requests.exceptions.ConnectionError:
            print(f"❌ Connection failed")
        except requests.exceptions.Timeout:
            print(f"❌ Timeout")
        except Exception as e:
            print(f"❌ Error: {str(e)}")
    
    print("\n❌ Could not find valid Zabbix API endpoint")
    return None, None


# Test your Zabbix server
zabbix_ip = "172.25.20.50"
correct_url, version = find_zabbix_api_url(zabbix_ip)

if correct_url:
    print(f"\n✅ Use this URL in your code:")
    print(f"   {correct_url}")
    print(f"\n📋 Zabbix Version: {version}")
else:
    print("\n⚠️  Troubleshooting steps:")
    print("   1. Check if Zabbix web interface is accessible")
    print("   2. Verify web server (Apache/Nginx) is running")
    print("   3. Check firewall settings")
    print("   4. Review web server configuration")
