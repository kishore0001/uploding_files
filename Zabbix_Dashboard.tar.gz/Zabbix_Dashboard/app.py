from flask import Flask, jsonify, render_template, Response, request
import requests
from typing import Optional, Dict, List
from datetime import datetime, time as dt_time, timedelta
import concurrent.futures
import os
import json
import threading
import time
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email import encoders
import logging
from datetime import datetime
import sys
app = Flask(__name__, static_folder='static')

class ZabbixAPI:
    """Zabbix 7.0 LTS API Client"""
    
    def __init__(self, url: str, location: str, username: Optional[str] = None, 
                 password: Optional[str] = None, token: Optional[str] = None):
        self.url = url
        self.location = location
        self.username = username
        self.password = password
        self.token = token
        self.auth_token = None
        self.session = requests.Session()
        self.session.headers.update({'Content-Type': 'application/json-rpc'})


# Configure logging
log_filename = f"zabbix_monitor_{datetime.now().strftime('%Y%m%d')}.log"

# Create logs directory if it doesn't exist
log_dir = "logs"
if not os.path.exists(log_dir):
    os.makedirs(log_dir)
    log_filename = os.path.join(log_dir, f"zabbix_monitor_{datetime.now().strftime('%Y%m%d')}.log")

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s | %(levelname)s | %(message)s',
    handlers=[
        logging.FileHandler(log_filename, encoding='utf-8'),
        # logging.StreamHandler(sys.stdout)  # Uncomment for console + file
    ],
    force=True
)

logger = logging.getLogger(__name__)

def log_message(message, level="INFO"):
    """Unified logging helper"""
    levels = {"DEBUG": logging.DEBUG, "INFO": logging.INFO, 
              "WARNING": logging.WARNING, "ERROR": logging.ERROR}
    logger.log(levels.get(level.upper(), logging.INFO), str(message))

    
    def _make_unauthenticated_request(self, method: str, params: Dict = None):
        if params is None:
            params = {}
            
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": 1
        }
        
        response = requests.post(
            self.url,
            json=payload,
            headers={'Content-Type': 'application/json-rpc'},
            timeout=30
        )
        
        response.raise_for_status()
        result = response.json()
        
        if 'error' in result:
            error_msg = result['error'].get('data', result['error'].get('message', 'Unknown error'))
            raise Exception(f"API Error [{method}]: {error_msg}")
        
        return result['result']
    
    def authenticate(self) -> str:
        if self.token:
            self.auth_token = self.token
            self.session.headers.update({'Authorization': f'Bearer {self.token}'})
            return self.token
        
        if not self.username or not self.password:
            raise ValueError("Either token or username/password must be provided")
        
        try:
            auth_token = self._make_unauthenticated_request(
                "user.login",
                {"username": self.username, "password": self.password}
            )
            self.auth_token = auth_token
            return self.auth_token
        except Exception as e:
            raise Exception(f"Authentication failed: {str(e)}")
    
    def make_request(self, method: str, params: Dict):
        if not self.auth_token and not self.token:
            raise Exception("Not authenticated. Call authenticate() first.")
        
        payload = {
            "jsonrpc": "2.0",
            "method": method,
            "params": params,
            "id": 2
        }
        
        if not self.token and self.auth_token:
            payload["auth"] = self.auth_token
        
        response = self.session.post(self.url, json=payload, timeout=30)
        response.raise_for_status()
        result = response.json()
        
        if 'error' in result:
            error_msg = result['error'].get('data', result['error'].get('message', 'Unknown error'))
            raise Exception(f"API Error [{method}]: {error_msg}")
        
        return result['result']
    
    def get_hosts_summary(self) -> Dict:
        params = {"output": ["hostid", "host", "name", "status"]}
        hosts = self.make_request("host.get", params)
        total = len(hosts)
        enabled = sum(1 for h in hosts if h['status'] == '0')
        disabled = total - enabled
        return {'total': total, 'enabled': enabled, 'disabled': disabled}
    
    def get_problem_hosts_summary(self) -> Dict:
        params = {
            "output": ["objectid", "eventid", "severity", "name", "clock"],
            "source": 0,
            "object": 0,
            "suppressed": False
        }
        problems = self.make_request("problem.get", params)
        warning = sum(1 for p in problems if int(p['severity']) in [2, 3])
        critical = sum(1 for p in problems if int(p['severity']) in [4, 5])
        problem_hostids = list(set(p['objectid'] for p in problems))
        return {
            'total_problems': len(problems),
            'warning': warning,
            'critical': critical,
            'problem_hosts': len(problem_hostids)
        }
    
    def get_hostgroups_with_details(self) -> List[Dict]:
        params = {
            "output": ["groupid", "name"],
            "selectHosts": ["hostid", "host", "name", "status"],
            "sortfield": "name",
            "sortorder": "ASC"
        }
        hostgroups = self.make_request("hostgroup.get", params)
        result = []
        for group in hostgroups:
            hosts = group.get('hosts', [])
            enabled_hosts = [h for h in hosts if h['status'] == '0']
            if enabled_hosts:
                hostids = [h['hostid'] for h in enabled_hosts]
                problem_data = self.get_problems_by_hostids(hostids)
                result.append({
                    'groupid': group['groupid'],
                    'name': group['name'],
                    'total_hosts': len(hosts),
                    'enabled_hosts': len(enabled_hosts),
                    'problem_hosts': len(problem_data['problem_hostids']),
                    'total_problems': problem_data['total_problems']
                })
            else:
                result.append({
                    'groupid': group['groupid'],
                    'name': group['name'],
                    'total_hosts': len(hosts),
                    'enabled_hosts': 0,
                    'problem_hosts': 0,
                    'total_problems': 0
                })
        return result
    
    def get_problems_by_hostids(self, hostids: List[str]) -> Dict:
        if not hostids:
            return {'problem_hostids': [], 'total_problems': 0, 'problems': []}
        params = {
            "output": ["objectid", "eventid", "severity", "name", "clock"],
            "source": 0,
            "object": 0,
            "suppressed": False,
            "hostids": hostids
        }
        problems = self.make_request("problem.get", params)
        problem_hostids = list(set(p['objectid'] for p in problems))
        return {
            'problem_hostids': problem_hostids,
            'total_problems': len(problems),
            'problems': problems
        }
    
    def get_problem_hosts_in_group(self, groupid: str) -> List[Dict]:
        try:
            params = {
                "output": ["hostid", "host", "name", "status"],
                "groupids": groupid,
                "filter": {"status": "0"},
                "selectTriggers": ["triggerid", "description", "priority", "value"]
            }
            hosts = self.make_request("host.get", params)
            if not hosts:
                return []
            result = []
            for host in hosts:
                triggers = host.get('triggers', [])
                problem_triggers = [t for t in triggers if t.get('value') == '1']
                if problem_triggers:
                    triggerids = [t['triggerid'] for t in problem_triggers]
                    params = {
                        "output": ["eventid", "name", "severity", "clock"],
                        "source": 0,
                        "object": 0,
                        "objectids": triggerids,
                        "value": 1,
                        "sortfield": ["clock"],
                        "sortorder": "DESC"
                    }
                    events = self.make_request("event.get", params)
                    if events:
                        problems_list = []
                        for event in events:
                            problems_list.append({
                                'eventid': event['eventid'],
                                'name': event['name'],
                                'severity': int(event['severity']),
                                'clock': int(event['clock'])
                            })
                        result.append({
                            'hostid': host['hostid'],
                            'host': host['host'],
                            'name': host['name'],
                            'problems': sorted(problems_list, key=lambda x: x['severity'], reverse=True)
                        })
            return result
        except Exception as e:
            print(f"Error: {str(e)}")
            raise


# ============================================================================
# SCHEDULER CONFIGURATION
# ============================================================================

SCHEDULES_FILE = 'schedules.json'

SMTP_CONFIG = {
    'server': 'smtp.gmail.com',
    'port': 587,
    'username': 'ohack6341@gmail.com',
    'password': 'gzebidymohwcchot',
    'from_email': 'ohack6341@gmail.com',
    'from_name': 'Zabbix Monitoring System'
}

active_schedule_threads = {}

def load_schedules():
    if os.path.exists(SCHEDULES_FILE):
        with open(SCHEDULES_FILE, 'r') as f:
            return json.load(f)
    return []

def save_schedules(schedules):
    with open(SCHEDULES_FILE, 'w') as f:
        json.dump(schedules, f, indent=2)

def generate_schedule_id():
    schedules = load_schedules()
    if not schedules:
        return 1
    return max(s['id'] for s in schedules) + 1

def send_email_report(recipients, subject, body, attachment_data=None, attachment_filename=None):
    try:
        msg = MIMEMultipart()
        msg['From'] = f"{SMTP_CONFIG['from_name']} <{SMTP_CONFIG['from_email']}>"
        msg['To'] = ', '.join(recipients) if isinstance(recipients, list) else recipients
        msg['Subject'] = subject
        msg.attach(MIMEText(body, 'html'))
        
        if attachment_data and attachment_filename:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment_data.encode('utf-8'))
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={attachment_filename}')
            msg.attach(part)
        
        server = smtplib.SMTP(SMTP_CONFIG['server'], SMTP_CONFIG['port'])
        server.starttls()
        server.login(SMTP_CONFIG['username'], SMTP_CONFIG['password'])
        server.send_message(msg)
        server.quit()
        
        print(f"✓ Email sent to {recipients}")
        return True
    except Exception as e:
        print(f"✗ Email error: {str(e)}")
        return False

def generate_problem_report(time_range='all', start_time=None, end_time=None):
    """Generate problem report - FIXED to handle custom days format"""
    try:
        now = datetime.now().timestamp()
        
        # Calculate time filter - FIXED to parse custom days
        if time_range == 'custom' and start_time and end_time:
            filter_start = start_time
            filter_end = end_time
            time_label = f"Custom ({datetime.fromtimestamp(filter_start).strftime('%Y-%m-%d')} to {datetime.fromtimestamp(filter_end).strftime('%Y-%m-%d')})"
        elif time_range == '24h':
            filter_start = now - (24 * 60 * 60)
            filter_end = now
            time_label = "Last 24 Hours"
        elif time_range == '7d':
            filter_start = now - (7 * 24 * 60 * 60)
            filter_end = now
            time_label = "Last 7 Days"
        elif time_range == '30d':
            filter_start = now - (30 * 24 * 60 * 60)
            filter_end = now
            time_label = "Last 30 Days"
        elif time_range.endswith('d'):  # FIXED: Handle custom days like "14d", "45d"
            days = int(time_range.replace('d', ''))
            filter_start = now - (days * 24 * 60 * 60)
            filter_end = now
            time_label = f"Last {days} Days"
        else:
            filter_start = 0
            filter_end = now
            time_label = "All Time (Current Active Only)"
        
        all_problems = []
        print(f"\n{'='*70}")
        print(f"GENERATING PROBLEM REPORT")
        print(f"Time Range: {time_label}")
        if filter_start > 0:
            print(f"From: {datetime.fromtimestamp(filter_start).strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"To: {datetime.fromtimestamp(filter_end).strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*70}")
        
        for location_name, config in ZABBIX_LOCATIONS.items():
            print(f"\n→ Location: {location_name}")
            try:
                zabbix = ZabbixAPI(
                    url=config['url'],
                    location=location_name,
                    token=config.get('token'),
                    username=config.get('username'),
                    password=config.get('password')
                )
                zabbix.authenticate()
                print(f"  ✓ Authenticated")
                
                # Get ALL problems
                print(f"  → Fetching all problems...")
                problem_params = {
                    "output": ["eventid", "objectid", "name", "severity", "clock", "r_eventid", "r_clock"],
                    "source": 0,
                    "object": 0,
                    "suppressed": False
                }
                
                problems = zabbix.make_request("problem.get", problem_params)
                print(f"  ✓ Retrieved {len(problems)} total problems")
                
                if len(problems) == 0:
                    print(f"  ⚠ No problems found")
                    continue
                
                # Get host details from triggers
                print(f"  → Getting host details...")
                trigger_ids = [p['objectid'] for p in problems]
                
                trigger_params = {
                    "output": ["triggerid", "description"],
                    "selectHosts": ["hostid", "host", "name"],
                    "triggerids": trigger_ids
                }
                triggers = zabbix.make_request("trigger.get", trigger_params)
                
                trigger_to_host = {}
                for trigger in triggers:
                    if trigger.get('hosts'):
                        trigger_to_host[trigger['triggerid']] = trigger['hosts'][0]
                
                print(f"  ✓ Mapped {len(trigger_to_host)} triggers to hosts")
                
                # Get hostgroup mapping
                hostgroup_params = {
                    "output": ["groupid", "name"],
                    "selectHosts": ["hostid"]
                }
                hostgroups = zabbix.make_request("hostgroup.get", hostgroup_params)
                
                host_to_group = {}
                for group in hostgroups:
                    for host in group.get('hosts', []):
                        host_to_group[host['hostid']] = group['name']
                
                # Process problems with time range filtering
                processed = 0
                filtered = 0
                
                for problem in problems:
                    trigger_id = problem['objectid']
                    host = trigger_to_host.get(trigger_id)
                    if not host:
                        continue
                    
                    problem_clock = int(problem.get('clock', 0))
                    if problem_clock == 0:
                        continue
                    
                    # Get resolution time
                    r_eventid = problem.get('r_eventid')
                    r_clock = problem.get('r_clock')
                    
                    problem_start = problem_clock
                    problem_end = None
                    
                    if r_eventid and str(r_eventid) != '0':
                        if r_clock and str(r_clock) != '0':
                            problem_end = int(r_clock)
                    
                    # TIME RANGE FILTERING LOGIC
                    if filter_start > 0:
                        include = False
                        
                        # Case 1: Problem started in range
                        if problem_start >= filter_start and problem_start <= filter_end:
                            include = True
                        
                        # Case 2: Problem was active during range
                        elif problem_start <= filter_end:
                            if problem_end is None:  # Still active
                                include = True
                            elif problem_end >= filter_start:  # Resolved during or after range
                                include = True
                        
                        if not include:
                            filtered += 1
                            continue
                    
                    # Build problem entry
                    hostid = host['hostid']
                    hostname = host['name']
                    host_technical = host['host']
                    hostgroup = host_to_group.get(hostid, 'Ungrouped')
                    
                    problem_name = problem.get('name', 'Unknown Problem')
                    severity = int(problem.get('severity', 0))
                    problem_time = datetime.fromtimestamp(problem_start)
                    
                    resolved_time = "Active (Not Resolved)"
                    if problem_end:
                        resolved_time = datetime.fromtimestamp(problem_end).strftime('%Y-%m-%d %H:%M:%S')
                    
                    all_problems.append({
                        'location': location_name,
                        'hostgroup': hostgroup,
                        'hostname': hostname,
                        'host': host_technical,
                        'problem': problem_name,
                        'severity': severity,
                        'created_time': problem_time.strftime('%Y-%m-%d %H:%M:%S'),
                        'resolved_time': resolved_time
                    })
                    processed += 1
                
                print(f"  ✓ Processed: {processed} problems")
                if filter_start > 0:
                    print(f"  ✓ Filtered out: {filtered} problems (outside time range)")
                
            except Exception as e:
                print(f"  ✗ ERROR: {str(e)}")
                import traceback
                traceback.print_exc()
        
        print(f"\n{'='*70}")
        print(f"EXPORT SUMMARY")
        print(f"Total Problems in Range: {len(all_problems)}")
        active = sum(1 for p in all_problems if 'Active' in p['resolved_time'])
        resolved = len(all_problems) - active
        print(f"Active: {active}")
        print(f"Resolved: {resolved}")
        
        if len(all_problems) > 0:
            severity_counts = {}
            for p in all_problems:
                sev = p['severity']
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
            
            print(f"\nBy Severity:")
            severity_names = {0: 'Not Classified', 1: 'Information', 2: 'Warning', 
                            3: 'Average', 4: 'High', 5: 'Disaster'}
            for sev in [5, 4, 3, 2, 1, 0]:
                if sev in severity_counts:
                    print(f"  {severity_names[sev]}: {severity_counts[sev]}")
        else:
            print(f"⚠ No problems found that were active during the selected time range")
        
        print(f"{'='*70}\n")
        
        return all_problems
        
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return []
        
def create_csv_from_problems(problems):
    """Create CSV string from problems list"""
    import csv
    from io import StringIO
    
    output = StringIO()
    writer = csv.writer(output)
    
    # Write header
    writer.writerow([
        'Location',
        'Hostgroup',
        'Hostname',
        'Host Technical Name',
        'Problem',
        'Severity',
        'Severity Name',
        'Created Time',
        'Resolved Time',
        'Status'
    ])
    
    # Severity mapping
    severity_names = {
        0: 'Not Classified',
        1: 'Information',
        2: 'Warning',
        3: 'Average',
        4: 'High',
        5: 'Disaster/Down'
    }
    
    # Write data
    for problem in problems:
        severity_num = problem.get('severity', 0)
        severity_name = severity_names.get(severity_num, 'Unknown')
        
        is_active = 'Active' in problem.get('resolved_time', 'Active')
        status = 'Active' if is_active else 'Resolved'
        
        writer.writerow([
            problem.get('location', ''),
            problem.get('hostgroup', ''),
            problem.get('hostname', ''),
            problem.get('host', ''),
            problem.get('problem', ''),
            severity_num,
            severity_name,
            problem.get('created_time', ''),
            problem.get('resolved_time', ''),
            status
        ])
    
    csv_string = output.getvalue()
    output.close()
    
    return csv_string




def execute_scheduled_report(schedule_id):
    """Execute a scheduled report and send email - FIXED to return result"""
    try:
        schedules = load_schedules()
        schedule = next((s for s in schedules if s['id'] == schedule_id), None)
        
        if not schedule:
            print(f"✗ Schedule {schedule_id} not found")
            return None
        
        print(f"{'='*70}")
        print(f"EXECUTING SCHEDULED REPORT")
        print(f"Schedule: {schedule['name']}")
        print(f"{'='*70}")
        
        # Get time range
        time_range = schedule.get('time_range', '24h')
        custom_days = schedule.get('custom_time_range_days')
        
        if time_range == 'custom_days' and custom_days:
            time_range = f"{custom_days}d"
        
        print(f"  → Generating report for time range: {time_range}")
        
        # Generate report
        problems = generate_problem_report(time_range=time_range)
        
        # Apply severity filter
        severity_filter = schedule.get('severity_filter', 'all')
        custom_severities = schedule.get('custom_severities')
        
        if severity_filter != 'all':
            original_count = len(problems)
            
            if severity_filter == 'custom' and custom_severities:
                problems = [p for p in problems if p['severity'] in custom_severities]
            elif severity_filter == 'disaster':
                problems = [p for p in problems if p['severity'] == 5]
            elif severity_filter == 'high':
                problems = [p for p in problems if p['severity'] >= 4]
            elif severity_filter == 'average':
                problems = [p for p in problems if p['severity'] >= 3]
            elif severity_filter == 'warning':
                problems = [p for p in problems if p['severity'] >= 2]
            elif severity_filter == 'information':
                problems = [p for p in problems if p['severity'] >= 1]
            
            print(f"  → Severity filter applied: {original_count} → {len(problems)} problems")
        
        # Apply hostgroup filter
        hostgroup_filter = schedule.get('hostgroup_filter', 'all')
        selected_hostgroups = schedule.get('selected_hostgroups')
        
        if hostgroup_filter == 'custom' and selected_hostgroups:
            original_count = len(problems)
            
            # Create set of (location, hostgroup) tuples for fast lookup
            allowed_groups = {(hg['location'], hg['name']) for hg in selected_hostgroups}
            problems = [p for p in problems if (p['location'], p['hostgroup']) in allowed_groups]
            
            print(f"  → Hostgroup filter applied: {original_count} → {len(problems)} problems")
        
        # Count active vs resolved
        active_count = sum(1 for p in problems if 'Active' in p['resolved_time'])
        resolved_count = len(problems) - active_count
        
        # Create CSV
        csv_data = create_csv_from_problems(problems)
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"iops_report_{timestamp}.csv"
        
        # Create email body with variables replaced
        body_template = schedule.get('body', '')
        
        body_vars = {
            '{{report_name}}': schedule['name'],
            '{{date}}': datetime.now().strftime('%B %d, %Y'),
            '{{time_range}}': time_range,
            '{{total_problems}}': str(len(problems)),
            '{{active_problems}}': str(active_count)
        }
        
        email_body = body_template
        for var, value in body_vars.items():
            email_body = email_body.replace(var, value)
        
        # Add problem summary
        email_body += f"""
        <br><br>
        <h3>Problem Summary</h3>
        <p><strong>Total Problems:</strong> {len(problems)}</p>
        <p><strong>Active:</strong> {active_count} | <strong>Resolved:</strong> {resolved_count}</p>
        <p><strong>Report attached:</strong> {filename}</p>
        """
        
        # Send email
        recipients = [r.strip() for r in schedule['recipients'].split(',')]
        subject = schedule['subject']
        
        success = send_email_report(recipients, subject, email_body, csv_data, filename)
        
        # Update schedule
        for i, s in enumerate(schedules):
            if s['id'] == schedule_id:
                schedules[i]['last_run'] = datetime.now().isoformat()
                schedules[i]['last_status'] = 'success' if success else 'failed'
                save_schedules(schedules)
                break
        
        print(f"\n✓ Report executed successfully")
        print(f"  → Total problems in report: {len(problems)}")
        print(f"  → Active: {active_count}, Resolved: {resolved_count}")
        print(f"  → Email status: {'Success' if success else 'Failed'}")
        print(f"{'='*70}\n")
        
        return {
            'success': success,
            'total_problems': len(problems),
            'active_problems': active_count,
            'resolved_problems': resolved_count
        }
        
    except Exception as e:
        print(f"\n✗ Error executing scheduled report: {str(e)}")
        import traceback
        traceback.print_exc()
        return None





def start_schedule(schedule):
    schedule_id = schedule['id']
    
    if schedule_id in active_schedule_threads:
        del active_schedule_threads[schedule_id]
    
    if schedule.get('active'):
        thread = threading.Thread(target=schedule_thread, args=(schedule,), daemon=True)
        thread.start()
        active_schedule_threads[schedule_id] = thread
        print(f"✓ Started schedule: {schedule['name']}")

def init_schedules():
    schedules = load_schedules()
    for schedule in schedules:
        if schedule.get('active'):
            start_schedule(schedule)


# ============================================================================
# CONFIGURATION
# ============================================================================

ZABBIX_LOCATIONS = {
    'Chennai': {
        'url': 'http://172.25.20.50/Iops/api_jsonrpc.php',
        'token': 'd5b2d767fade6902450a857f8b1bab96af6388cc8e104d42a10ab60314588c36',
        'username': 'API',
        'password': 'zabbix@123'
    },
}

def fetch_location_summary(location_name: str, config: Dict) -> Dict:
    try:
        zabbix = ZabbixAPI(
            url=config['url'],
            location=location_name,
            token=config.get('token'),
            username=config.get('username'),
            password=config.get('password')
        )
        zabbix.authenticate()
        hosts_data = zabbix.get_hosts_summary()
        problems_data = zabbix.get_problem_hosts_summary()
        return {
            'location': location_name,
            'success': True,
            'total_hosts': hosts_data['total'],
            'enabled_hosts': hosts_data['enabled'],
            'disabled_hosts': hosts_data['disabled'],
            'problem_hosts': problems_data['problem_hosts'],
            'warning_count': problems_data['warning'],
            'critical_count': problems_data['critical'],
            'total_problems': problems_data['total_problems']
        }
    except Exception as e:
        return {'location': location_name, 'success': False, 'error': str(e)}


# ============================================================================
# ROUTES
# ============================================================================

@app.route('/')
def index():
    # Check if locations are configured
    if not ZABBIX_LOCATIONS:
        return "Error: No Zabbix locations configured in ZABBIX_LOCATIONS", 500
    return render_template('page1_index.html')


@app.route('/location/<location_name>')
def location_hostgroups(location_name):
    return render_template('page2_hostgroups.html', location_name=location_name)

@app.route('/schedule')
def schedule_page():
    return render_template('schedule.html')



@app.route('/api/location/<location_name>/hostgroups')
def get_location_hostgroups(location_name):
    try:
        if location_name not in ZABBIX_LOCATIONS:
            return jsonify({'success': False, 'error': 'Location not found'}), 404
        config = ZABBIX_LOCATIONS[location_name]
        zabbix = ZabbixAPI(url=config['url'], location=location_name,
                          token=config.get('token'), username=config.get('username'),
                          password=config.get('password'))
        zabbix.authenticate()
        hostgroups = zabbix.get_hostgroups_with_details()
        return jsonify({'success': True, 'location': location_name, 'hostgroups': hostgroups})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/schedules', methods=['GET'])
def get_schedules():
    try:
        return jsonify({'success': True, 'schedules': load_schedules()})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules', methods=['POST'])
def create_schedule():
    try:
        data = request.json
        schedule = {
            'id': generate_schedule_id(),
            'name': data.get('name'),
            'description': data.get('description', ''),
            'active': data.get('active', True),
            'frequency': data.get('frequency', 'daily'),
            'custom_interval': data.get('custom_interval'),
            'time': data.get('time', '09:00'),
            'time_range': data.get('time_range', '24h'),
            'custom_time_range_days': data.get('custom_time_range_days'),
            'severity_filter': data.get('severity_filter', 'all'),
            'custom_severities': data.get('custom_severities'),
            'hostgroup_filter': data.get('hostgroup_filter', 'all'),  # FIXED
            'selected_hostgroups': data.get('selected_hostgroups'),  # FIXED
            'recipients': data.get('recipients', ''),
            'subject': data.get('subject', 'Zabbix Report'),
            'body': data.get('body', ''),
            'created_at': datetime.now().isoformat(),
            'last_run': None,
            'last_status': None
        }
        schedules = load_schedules()
        schedules.append(schedule)
        save_schedules(schedules)
        if schedule['active']:
            start_schedule(schedule)
        return jsonify({'success': True, 'schedule': schedule})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# FIX 2: Update update_schedule route to include ALL fields
# ============================================================================

@app.route('/api/schedules/<int:schedule_id>', methods=['PUT'])
def update_schedule(schedule_id):
    try:
        data = request.json
        schedules = load_schedules()
        for i, s in enumerate(schedules):
            if s['id'] == schedule_id:
                # Update ALL fields - FIXED
                schedules[i].update({
                    'name': data.get('name', s['name']),
                    'description': data.get('description', s.get('description', '')),
                    'active': data.get('active', s['active']),
                    'frequency': data.get('frequency', s['frequency']),
                    'custom_interval': data.get('custom_interval', s.get('custom_interval')),
                    'time': data.get('time', s['time']),
                    'time_range': data.get('time_range', s.get('time_range', '24h')),
                    'custom_time_range_days': data.get('custom_time_range_days', s.get('custom_time_range_days')),
                    'severity_filter': data.get('severity_filter', s.get('severity_filter', 'all')),
                    'custom_severities': data.get('custom_severities', s.get('custom_severities')),
                    'hostgroup_filter': data.get('hostgroup_filter', s.get('hostgroup_filter', 'all')),  # FIXED
                    'selected_hostgroups': data.get('selected_hostgroups', s.get('selected_hostgroups')),  # FIXED
                    'recipients': data.get('recipients', s['recipients']),
                    'subject': data.get('subject', s['subject']),
                    'body': data.get('body', s.get('body', ''))
                })
                save_schedules(schedules)
                start_schedule(schedules[i])
                return jsonify({'success': True, 'schedule': schedules[i]})
        return jsonify({'success': False, 'error': 'Not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500





def schedule_thread(schedule):
    """FIXED - Properly waits and executes"""
    schedule_id = schedule['id']
    
    print(f"\n{'='*70}")
    print(f"✓ Scheduler started: {schedule['name']}")
    print(f"  ID: {schedule_id}")
    print(f"  Frequency: {schedule.get('frequency', 'daily')}")
    print(f"  Time: {schedule.get('time', '09:00')}")
    print(f"{'='*70}\n")
    
    while schedule_id in active_schedule_threads:
        try:
            # Reload schedule
            schedules = load_schedules()
            current_schedule = next((s for s in schedules if s['id'] == schedule_id), None)
            
            if not current_schedule or not current_schedule.get('active'):
                print(f"✗ Schedule {schedule_id} stopped (inactive)")
                break
            
            # Calculate next run
            next_run = get_next_run_time(current_schedule)
            now = datetime.now()
            wait_seconds = (next_run - now).total_seconds()
            
            # If we need to wait
            if wait_seconds > 5:  # More than 5 seconds away
                print(f"⏰ [{now.strftime('%H:%M:%S')}] Next run: {next_run.strftime('%Y-%m-%d %H:%M:%S')} (in {int(wait_seconds)}s)")
                
                # Sleep in 30-second chunks so we can check for updates
                while wait_seconds > 5 and schedule_id in active_schedule_threads:
                    time.sleep(min(30, wait_seconds))
                    
                    # Recalculate
                    now = datetime.now()
                    wait_seconds = (next_run - now).total_seconds()
                
                # Loop back to check if schedule changed
                continue
            
            # We're close to run time (within 5 seconds)
            if wait_seconds > 0:
                print(f"⏳ Waiting {int(wait_seconds)}s until {next_run.strftime('%H:%M:%S')}...")
                time.sleep(wait_seconds)
            
            # EXECUTE NOW
            print(f"\n{'='*70}")
            print(f"🚀 EXECUTING SCHEDULED REPORT")
            print(f"   Schedule: {current_schedule['name']}")
            print(f"   Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*70}\n")
            
            execute_scheduled_report(schedule_id)
            
            # Sleep to prevent duplicate runs
            print(f"✓ Execution complete. Sleeping 60s...\n")
            time.sleep(60)
            
        except Exception as e:
            print(f"\n✗ Scheduler error: {str(e)}")
            import traceback
            traceback.print_exc()
            time.sleep(60)
    
    print(f"\n✗ Scheduler stopped: {schedule['name']}\n")





def send_email_report(recipients, subject, body, attachment_data=None, attachment_filename=None):
    """Send email with better error handling and logging"""
    try:
        print(f"\n📧 Preparing email...")
        print(f"  Recipients: {recipients}")
        print(f"  Subject: {subject}")
        print(f"  SMTP Server: {SMTP_CONFIG['server']}:{SMTP_CONFIG['port']}")
        print(f"  From: {SMTP_CONFIG['from_email']}")
        
        # Create message
        msg = MIMEMultipart()
        msg['From'] = f"{SMTP_CONFIG['from_name']} <{SMTP_CONFIG['from_email']}>"
        msg['To'] = ', '.join(recipients) if isinstance(recipients, list) else recipients
        msg['Subject'] = subject
        
        # Attach body
        msg.attach(MIMEText(body, 'html'))
        
        # Attach CSV if provided
        if attachment_data and attachment_filename:
            part = MIMEBase('application', 'octet-stream')
            part.set_payload(attachment_data.encode('utf-8'))
            encoders.encode_base64(part)
            part.add_header('Content-Disposition', f'attachment; filename={attachment_filename}')
            msg.attach(part)
            print(f"  ✓ Attachment added: {attachment_filename}")
        
        # Connect and send
        print(f"  → Connecting to SMTP server...")
        server = smtplib.SMTP(SMTP_CONFIG['server'], SMTP_CONFIG['port'], timeout=30)
        server.set_debuglevel(0)  # Set to 1 for verbose SMTP debugging
        
        print(f"  → Starting TLS...")
        server.starttls()
        
        print(f"  → Logging in...")
        server.login(SMTP_CONFIG['username'], SMTP_CONFIG['password'])
        
        print(f"  → Sending message...")
        server.send_message(msg)
        
        server.quit()
        
        print(f"  ✅ Email sent successfully!")
        return True
        
    except smtplib.SMTPAuthenticationError as e:
        print(f"  ❌ SMTP Authentication Error: {str(e)}")
        print(f"     Check your email/password in SMTP_CONFIG")
        return False
    except smtplib.SMTPException as e:
        print(f"  ❌ SMTP Error: {str(e)}")
        return False
    except Exception as e:
        print(f"  ❌ Email error: {str(e)}")
        import traceback
        traceback.print_exc()
        return False



def get_next_run_time(schedule):
    """Calculate next run time - FINAL VERSION"""
    now = datetime.now()
    target_time = datetime.strptime(schedule.get('time', '09:00'), '%H:%M').time()
    
    # Get last run
    last_run = schedule.get('last_run')
    last_run_date = None
    already_ran_today = False
    
    if last_run:
        try:
            last_run_dt = datetime.fromisoformat(last_run)
            last_run_date = last_run_dt.date()
            if last_run_date == now.date():
                already_ran_today = True
        except:
            pass
    
    frequency = schedule.get('frequency', 'daily')
    
    # Simple logic for daily
    if frequency == 'daily':
        if already_ran_today:
            next_date = now.date() + timedelta(days=1)
        elif now.time() > target_time:
            next_date = now.date() + timedelta(days=1)
        else:
            next_date = now.date()
    
    # Other frequencies
    elif frequency in ['every_2_days', 'every_3_days']:
        days = 2 if frequency == 'every_2_days' else 3
        if last_run_date and not already_ran_today:
            next_date = last_run_date + timedelta(days=days)
            while next_date < now.date():
                next_date += timedelta(days=days)
            if next_date == now.date() and now.time() > target_time:
                next_date += timedelta(days=days)
        elif already_ran_today:
            next_date = last_run_date + timedelta(days=days)
        else:
            next_date = now.date()
            if now.time() > target_time:
                next_date += timedelta(days=1)
    
    elif frequency == 'weekly':
        days = 7
        if last_run_date and not already_ran_today:
            next_date = last_run_date + timedelta(days=days)
            while next_date < now.date():
                next_date += timedelta(days=days)
            if next_date == now.date() and now.time() > target_time:
                next_date += timedelta(days=days)
        elif already_ran_today:
            next_date = last_run_date + timedelta(days=days)
        else:
            next_date = now.date()
            if now.time() > target_time:
                next_date += timedelta(days=1)
    
    elif frequency == 'biweekly':
        days = 14
        if last_run_date and not already_ran_today:
            next_date = last_run_date + timedelta(days=days)
            while next_date < now.date():
                next_date += timedelta(days=days)
            if next_date == now.date() and now.time() > target_time:
                next_date += timedelta(days=days)
        elif already_ran_today:
            next_date = last_run_date + timedelta(days=days)
        else:
            next_date = now.date()
            if now.time() > target_time:
                next_date += timedelta(days=1)
    
    elif frequency == 'monthly':
        days = 30
        if last_run_date and not already_ran_today:
            next_date = last_run_date + timedelta(days=days)
            while next_date < now.date():
                next_date += timedelta(days=days)
            if next_date == now.date() and now.time() > target_time:
                next_date += timedelta(days=days)
        elif already_ran_today:
            next_date = last_run_date + timedelta(days=days)
        else:
            next_date = now.date()
            if now.time() > target_time:
                next_date += timedelta(days=1)
    
    elif frequency == 'custom':
        days = schedule.get('custom_interval', 1)
        if last_run_date and not already_ran_today:
            next_date = last_run_date + timedelta(days=days)
            while next_date < now.date():
                next_date += timedelta(days=days)
            if next_date == now.date() and now.time() > target_time:
                next_date += timedelta(days=days)
        elif already_ran_today:
            next_date = last_run_date + timedelta(days=days)
        else:
            next_date = now.date()
            if now.time() > target_time:
                next_date += timedelta(days=1)
    
    else:
        next_date = now.date()
        if now.time() > target_time:
            next_date += timedelta(days=1)
    
    return datetime.combine(next_date, target_time)


def schedule_thread(schedule):
    """Scheduler thread - COMPLETE FIXED VERSION"""
    schedule_id = schedule['id']
    
    print(f"\n{'='*70}")
    print(f"✓ Scheduler started: {schedule['name']}")
    print(f"  ID: {schedule_id}")
    print(f"  Frequency: {schedule.get('frequency', 'daily')}")
    print(f"  Time: {schedule.get('time', '09:00')}")
    print(f"{'='*70}\n")
    
    while schedule_id in active_schedule_threads:
        try:
            # Reload schedule
            schedules = load_schedules()
            current_schedule = next((s for s in schedules if s['id'] == schedule_id), None)
            
            if not current_schedule or not current_schedule.get('active'):
                print(f"✗ Schedule stopped (inactive)")
                break
            
            # Calculate next run
            next_run = get_next_run_time(current_schedule)
            now = datetime.now()
            wait_seconds = (next_run - now).total_seconds()
            
            # If more than 5 seconds away, sleep and check again
            if wait_seconds > 5:
                print(f"⏰ [{now.strftime('%H:%M:%S')}] Next run: {next_run.strftime('%Y-%m-%d %H:%M:%S')} (in {int(wait_seconds)}s)")
                
                # Sleep in 30-second chunks to allow for updates
                while wait_seconds > 5 and schedule_id in active_schedule_threads:
                    time.sleep(min(30, wait_seconds))
                    now = datetime.now()
                    wait_seconds = (next_run - now).total_seconds()
                
                continue  # Loop back to recalculate
            
            # We're within 5 seconds - wait the exact time
            if wait_seconds > 0:
                print(f"⏳ Waiting {int(wait_seconds)}s until {next_run.strftime('%H:%M:%S')}...")
                time.sleep(wait_seconds)
            
            # EXECUTE NOW!
            print(f"\n{'='*70}")
            print(f"🚀 EXECUTING SCHEDULED REPORT")
            print(f"   Schedule: {current_schedule['name']}")
            print(f"   Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
            print(f"{'='*70}\n")
            
            execute_scheduled_report(schedule_id)
            
            print(f"✓ Execution complete. Sleeping 60s to prevent duplicates...\n")
            time.sleep(60)
            
        except Exception as e:
            print(f"\n✗ Scheduler error: {str(e)}")
            import traceback
            traceback.print_exc()
            time.sleep(60)
    
    print(f"\n✗ Scheduler stopped: {schedule['name']}\n")



@app.route('/availability')
def availability_page():
    """Host availability dashboard page"""
    return render_template('availability.html')


@app.route('/api/host-availability')
def get_host_availability():
    """Calculate host availability for time range - EXCLUDES MAINTENANCE"""
    try:
        time_range = request.args.get('range', '24h')
        location_filter = request.args.get('location', 'all')
        search_query = request.args.get('search', '').lower()
        
        # Calculate time range
        now = datetime.now()
        if time_range == '24h':
            time_from = int((now - timedelta(hours=24)).timestamp())
        elif time_range == '7d':
            time_from = int((now - timedelta(days=7)).timestamp())
        elif time_range == '30d':
            time_from = int((now - timedelta(days=30)).timestamp())
        elif time_range == 'custom':
            start = request.args.get('start')
            end = request.args.get('end')
            if start and end:
                time_from = int(start)
                time_till = int(end)
                now = datetime.fromtimestamp(time_till)
            else:
                return jsonify({'success': False, 'error': 'Custom range requires start and end'}), 400
        else:
            time_from = int((now - timedelta(hours=24)).timestamp())
        
        time_till = int(now.timestamp())
        total_duration = time_till - time_from
        
        print(f"\n{'='*70}")
        print(f"CALCULATING HOST AVAILABILITY")
        print(f"  Time Range: {time_range}")
        print(f"  From: {datetime.fromtimestamp(time_from).strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  To: {datetime.fromtimestamp(time_till).strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"  Duration: {total_duration}s ({total_duration/3600:.1f} hours)")
        print(f"  Search Query: '{search_query}'")
        print(f"  Maintenance: EXCLUDED from downtime")
        print(f"{'='*70}\n")
        
        all_hosts = []
        
        for location_name, config in ZABBIX_LOCATIONS.items():
            # Apply location filter
            if location_filter != 'all' and location_filter != location_name:
                continue
            
            try:
                api = ZabbixAPI(
                    config['url'],
                    location_name,
                    username=config.get('username'),
                    password=config.get('password'),
                    token=config.get('token')
                )
                
                if not api.authenticate():
                    print(f"✗ Failed to authenticate to {location_name}")
                    continue
                
                # Get all hosts with interfaces (to get IP addresses)
                hosts_response = api.make_request('host.get', {
                    'output': ['hostid', 'host', 'name', 'status'],
                    'selectGroups': ['name'],
                    'selectInterfaces': ['ip', 'dns', 'type']
                })
                
                if not hosts_response:
                    continue
                
                for host in hosts_response:
                    hostname = host.get('name', host.get('host', 'Unknown'))
                    host_technical = host.get('host', '')
                    
                    # Get IP addresses from interfaces
                    interfaces = host.get('interfaces', [])
                    ip_addresses = []
                    for interface in interfaces:
                        ip = interface.get('ip', '')
                        dns = interface.get('dns', '')
                        if ip:
                            ip_addresses.append(ip)
                        if dns:
                            ip_addresses.append(dns)
                    
                    # ENHANCED SEARCH: Check hostname, technical name, and IP addresses
                    if search_query:
                        search_match = (
                            search_query in hostname.lower() or
                            search_query in host_technical.lower() or
                            any(search_query in ip.lower() for ip in ip_addresses)
                        )
                        
                        if not search_match:
                            continue
                    
                    hostgroup = host.get('groups', [{}])[0].get('name', 'No Group')
                    host_status = int(host.get('status', 0))
                    
                    # Primary IP (first interface IP)
                    primary_ip = ip_addresses[0] if ip_addresses else 'N/A'
                    all_ips = ', '.join(ip_addresses) if ip_addresses else 'N/A'
                    
                    # ===================================================================
                    # GET REAL DOWNTIME PROBLEMS (EXCLUDING MAINTENANCE)
                    # ===================================================================
                    problems_response = api.make_request('problem.get', {
                        'output': ['eventid', 'name', 'severity', 'clock', 'r_clock', 'suppressed'],
                        'hostids': [host['hostid']],
                        'time_from': time_from,
                        'time_till': time_till,
                        'severities': [5],  # Only "Down" severity
                        'recent': False,
                        'suppressed': False  # ← KEY FIX: Exclude suppressed (maintenance) problems
                    })
                    
                    # Get maintenance problems separately for reporting
                    maintenance_problems = api.make_request('problem.get', {
                        'output': ['eventid', 'name', 'severity', 'clock', 'r_clock', 'suppressed'],
                        'hostids': [host['hostid']],
                        'time_from': time_from,
                        'time_till': time_till,
                        'severities': [5],
                        'recent': False,
                        'suppressed': True  # ← Get ONLY maintenance problems
                    })
                    
                    # Calculate real downtime (unplanned)
                    total_downtime = 0
                    downtime_periods = []
                    
                    if problems_response:
                        for problem in problems_response:
                            problem_start = int(problem['clock'])
                            problem_end = int(problem.get('r_clock', time_till))
                            
                            # Clamp to our time range
                            problem_start = max(problem_start, time_from)
                            problem_end = min(problem_end, time_till)
                            
                            downtime = problem_end - problem_start
                            if downtime > 0:
                                total_downtime += downtime
                                downtime_periods.append({
                                    'start': datetime.fromtimestamp(problem_start).strftime('%Y-%m-%d %H:%M:%S'),
                                    'end': datetime.fromtimestamp(problem_end).strftime('%Y-%m-%d %H:%M:%S'),
                                    'duration': downtime,
                                    'type': 'Unplanned'
                                })
                    
                    # Calculate maintenance time (for reporting only)
                    total_maintenance_time = 0
                    maintenance_periods = []
                    
                    if maintenance_problems:
                        for problem in maintenance_problems:
                            problem_start = int(problem['clock'])
                            problem_end = int(problem.get('r_clock', time_till))
                            
                            # Clamp to our time range
                            problem_start = max(problem_start, time_from)
                            problem_end = min(problem_end, time_till)
                            
                            maintenance_time = problem_end - problem_start
                            if maintenance_time > 0:
                                total_maintenance_time += maintenance_time
                                maintenance_periods.append({
                                    'start': datetime.fromtimestamp(problem_start).strftime('%Y-%m-%d %H:%M:%S'),
                                    'end': datetime.fromtimestamp(problem_end).strftime('%Y-%m-%d %H:%M:%S'),
                                    'duration': maintenance_time,
                                    'type': 'Maintenance'
                                })
                    
                    # Calculate availability (maintenance excluded)
                    uptime = total_duration - total_downtime
                    availability_pct = (uptime / total_duration * 100) if total_duration > 0 else 100
                    
                    # Status classification
                    if host_status == 1:
                        status = 'Disabled'
                        status_color = 'gray'
                    elif availability_pct >= 99.9:
                        status = 'Excellent'
                        status_color = 'green'
                    elif availability_pct >= 99:
                        status = 'Good'
                        status_color = 'lightgreen'
                    elif availability_pct >= 95:
                        status = 'Fair'
                        status_color = 'yellow'
                    else:
                        status = 'Poor'
                        status_color = 'red'
                    
                    all_hosts.append({
                        'location': location_name,
                        'hostgroup': hostgroup,
                        'hostname': hostname,
                        'host_technical': host_technical,
                        'ip_address': primary_ip,
                        'all_ips': all_ips,
                        'availability': round(availability_pct, 2),
                        'uptime_seconds': uptime,
                        'downtime_seconds': total_downtime,
                        'maintenance_seconds': total_maintenance_time,
                        'downtime_formatted': format_duration(total_downtime),
                        'uptime_formatted': format_duration(uptime),
                        'maintenance_formatted': format_duration(total_maintenance_time),
                        'status': status,
                        'status_color': status_color,
                        'downtime_periods': downtime_periods,
                        'maintenance_periods': maintenance_periods,
                        'is_disabled': host_status == 1
                    })
                
                print(f"✓ Processed {len(hosts_response)} hosts from {location_name}")
                
            except Exception as e:
                print(f"✗ Error processing {location_name}: {str(e)}")
                import traceback
                traceback.print_exc()
                continue
        
        # Sort by availability (lowest first)
        all_hosts.sort(key=lambda x: x['availability'])
        
        print(f"\n✓ Total hosts processed: {len(all_hosts)}")
        if search_query:
            print(f"✓ Hosts matching search '{search_query}': {len(all_hosts)}")
        print(f"{'='*70}\n")
        
        return jsonify({
            'success': True,
            'hosts': all_hosts,
            'time_range': {
                'from': datetime.fromtimestamp(time_from).strftime('%Y-%m-%d %H:%M:%S'),
                'to': datetime.fromtimestamp(time_till).strftime('%Y-%m-%d %H:%M:%S'),
                'duration_hours': round(total_duration / 3600, 1)
            }
        })
        
    except Exception as e:
        print(f"✗ Error calculating availability: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500


def format_duration(seconds):
    """Format seconds into human-readable duration"""
    if seconds == 0:
        return "0s"
    
    days = seconds // 86400
    hours = (seconds % 86400) // 3600
    minutes = (seconds % 3600) // 60
    secs = seconds % 60
    
    parts = []
    if days > 0:
        parts.append(f"{days}d")
    if hours > 0:
        parts.append(f"{hours}h")
    if minutes > 0:
        parts.append(f"{minutes}m")
    if secs > 0 and days == 0:
        parts.append(f"{secs}s")
    
    return " ".join(parts) if parts else "0s"


@app.route('/api/export/availability')
def export_availability():
    """Export availability data to CSV"""
    try:
        import csv
        from io import StringIO
        
        time_range = request.args.get('range', '24h')
        location_filter = request.args.get('location', 'all')
        search_query = request.args.get('search', '')
        
        # Calculate time range
        now = datetime.now()
        if time_range == '24h':
            time_from = int((now - timedelta(hours=24)).timestamp())
        elif time_range == '7d':
            time_from = int((now - timedelta(days=7)).timestamp())
        elif time_range == '30d':
            time_from = int((now - timedelta(days=30)).timestamp())
        elif time_range == 'custom':
            start = request.args.get('start')
            end = request.args.get('end')
            if start and end:
                time_from = int(start)
                time_till = int(end)
                now = datetime.fromtimestamp(time_till)
            else:
                return "Error: Custom range requires start and end", 400
        else:
            time_from = int((now - timedelta(hours=24)).timestamp())
        
        time_till = int(now.timestamp())
        total_duration = time_till - time_from
        
        print(f"\n{'='*70}")
        print(f"EXPORTING AVAILABILITY DATA")
        print(f"  Time Range: {time_range}")
        print(f"  Location Filter: {location_filter}")
        print(f"  Search Query: '{search_query}'")
        print(f"{'='*70}\n")
        
        all_hosts = []
        
        for location_name, config in ZABBIX_LOCATIONS.items():
            if location_filter != 'all' and location_filter != location_name:
                continue
            
            try:
                api = ZabbixAPI(
                    config['url'],
                    location_name,
                    username=config.get('username'),
                    password=config.get('password'),
                    token=config.get('token')
                )
                
                if not api.authenticate():
                    continue
                
                hosts_response = api.make_request('host.get', {
                    'output': ['hostid', 'host', 'name', 'status'],
                    'selectGroups': ['name'],
                    'selectInterfaces': ['ip', 'dns', 'type']
                })
                
                if not hosts_response:
                    continue
                
                for host in hosts_response:
                    hostname = host.get('name', host.get('host', 'Unknown'))
                    host_technical = host.get('host', '')
                    
                    interfaces = host.get('interfaces', [])
                    ip_addresses = []
                    for interface in interfaces:
                        ip = interface.get('ip', '')
                        dns = interface.get('dns', '')
                        if ip:
                            ip_addresses.append(ip)
                        if dns:
                            ip_addresses.append(dns)
                    
                    if search_query:
                        search_query_lower = search_query.lower()
                        search_match = (
                            search_query_lower in hostname.lower() or
                            search_query_lower in host_technical.lower() or
                            any(search_query_lower in ip.lower() for ip in ip_addresses)
                        )
                        
                        if not search_match:
                            continue
                    
                    hostgroup = host.get('groups', [{}])[0].get('name', 'No Group')
                    host_status = int(host.get('status', 0))
                    primary_ip = ip_addresses[0] if ip_addresses else 'N/A'
                    all_ips = ', '.join(ip_addresses) if ip_addresses else 'N/A'
                    
                    # Get real problems (excluding maintenance)
                    problems_response = api.make_request('problem.get', {
                        'output': ['eventid', 'name', 'severity', 'clock', 'r_clock'],
                        'hostids': [host['hostid']],
                        'time_from': time_from,
                        'time_till': time_till,
                        'severities': [5],
                        'recent': False,
                        'suppressed': False  # Exclude maintenance
                    })
                    
                    # Get maintenance problems
                    maintenance_problems = api.make_request('problem.get', {
                        'output': ['eventid', 'name', 'severity', 'clock', 'r_clock'],
                        'hostids': [host['hostid']],
                        'time_from': time_from,
                        'time_till': time_till,
                        'severities': [5],
                        'recent': False,
                        'suppressed': True  # Only maintenance
                    })
                    
                    total_downtime = 0
                    if problems_response:
                        for problem in problems_response:
                            problem_start = int(problem['clock'])
                            problem_end = int(problem.get('r_clock', time_till))
                            
                            problem_start = max(problem_start, time_from)
                            problem_end = min(problem_end, time_till)
                            
                            downtime = problem_end - problem_start
                            if downtime > 0:
                                total_downtime += downtime
                    
                    total_maintenance_time = 0
                    if maintenance_problems:
                        for problem in maintenance_problems:
                            problem_start = int(problem['clock'])
                            problem_end = int(problem.get('r_clock', time_till))
                            
                            problem_start = max(problem_start, time_from)
                            problem_end = min(problem_end, time_till)
                            
                            maintenance_time = problem_end - problem_start
                            if maintenance_time > 0:
                                total_maintenance_time += maintenance_time
                    
                    uptime = total_duration - total_downtime
                    availability_pct = (uptime / total_duration * 100) if total_duration > 0 else 100
                    
                    if host_status == 1:
                        status = 'Disabled'
                    elif availability_pct >= 99.9:
                        status = 'Excellent'
                    elif availability_pct >= 99:
                        status = 'Good'
                    elif availability_pct >= 95:
                        status = 'Fair'
                    else:
                        status = 'Poor'
                    
                    all_hosts.append({
                        'location': location_name,
                        'hostgroup': hostgroup,
                        'hostname': hostname,
                        'host_technical': host_technical,
                        'ip_address': primary_ip,
                        'all_ips': all_ips,
                        'availability': round(availability_pct, 2),
                        'uptime_seconds': uptime,
                        'downtime_seconds': total_downtime,
                        'maintenance_seconds': total_maintenance_time,
                        'downtime_formatted': format_duration(total_downtime),
                        'uptime_formatted': format_duration(uptime),
                        'maintenance_formatted': format_duration(total_maintenance_time),
                        'status': status,
                        'is_disabled': host_status == 1
                    })
                
            except Exception as e:
                print(f"✗ Error processing {location_name}: {str(e)}")
                continue
        
        all_hosts.sort(key=lambda x: x['availability'])
        
        # Create CSV
        output = StringIO()
        writer = csv.writer(output)
        
        writer.writerow([
            'Location',
            'Hostgroup',
            'Hostname',
            'Host Technical Name',
            'IP Address',
            'All IP Addresses',
            'Availability %',
            'Uptime',
            'Downtime (Unplanned)',
            'Maintenance Time',
            'Status'
        ])
        
        for host in all_hosts:
            writer.writerow([
                host['location'],
                host['hostgroup'],
                host['hostname'],
                host['host_technical'],
                host['ip_address'],
                host['all_ips'],
                f"{host['availability']}%",
                host['uptime_formatted'],
                host['downtime_formatted'],
                host['maintenance_formatted'],
                host['status']
            ])
        
        csv_data = output.getvalue()
        output.close()
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"host_availability_{time_range}_{timestamp}.csv"
        
        print(f"✓ Exported {len(all_hosts)} hosts to CSV")
        print(f"  Filename: {filename}\n")
        
        return Response(
            csv_data,
            mimetype='text/csv',
            headers={'Content-Disposition': f'attachment; filename={filename}'}
        )
        
    except Exception as e:
        print(f"✗ Error exporting availability: {str(e)}")
        import traceback
        traceback.print_exc()
        return f"Error: {str(e)}", 500




@app.route('/api/schedules/<int:schedule_id>', methods=['DELETE'])
def delete_schedule(schedule_id):
    try:
        schedules = [s for s in load_schedules() if s['id'] != schedule_id]
        save_schedules(schedules)
        if schedule_id in active_schedule_threads:
            del active_schedule_threads[schedule_id]
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/schedules/<int:schedule_id>/toggle', methods=['POST'])
def toggle_schedule(schedule_id):
    try:
        schedules = load_schedules()
        for s in schedules:
            if s['id'] == schedule_id:
                s['active'] = not s.get('active', True)
                save_schedules(schedules)
                start_schedule(s)
                return jsonify({'success': True, 'active': s['active']})
        return jsonify({'success': False, 'error': 'Not found'}), 404
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/schedules/<int:schedule_id>/test', methods=['POST'])
def test_schedule(schedule_id):
    try:
        execute_scheduled_report(schedule_id)
        return jsonify({'success': True, 'message': 'Test email sent'})
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/debug/compare-problems')
def debug_compare_problems():
    """Compare dashboard problems vs export problems"""
    try:
        location_name = 'Chennai'
        config = ZABBIX_LOCATIONS[location_name]
        
        zabbix = ZabbixAPI(
            url=config['url'],
            location=location_name,
            token=config.get('token')
        )
        zabbix.authenticate()
        
        # METHOD 1: Dashboard query (what you see)
        dashboard_params = {
            "output": ["objectid", "eventid", "severity", "name", "clock"],
            "source": 0,
            "object": 0,
            "suppressed": False
        }
        dashboard_problems = zabbix.make_request("problem.get", dashboard_params)
        
        # METHOD 2: Export query (without selectHosts)
        export_params = {
            "output": ["eventid", "objectid", "name", "severity", "clock"],
            "source": 0,
            "object": 0,
            "suppressed": False
        }
        export_problems = zabbix.make_request("problem.get", export_params)
        
        return jsonify({
            'success': True,
            'dashboard_count': len(dashboard_problems),
            'export_count': len(export_problems),
            'dashboard_sample': dashboard_problems[:3],
            'export_sample': export_problems[:3],
            'match': len(dashboard_problems) == len(export_problems)
        })
        
    except Exception as e:
        import traceback
        return jsonify({
            'success': False,
            'error': str(e),
            'traceback': traceback.format_exc()
        }), 500


@app.route('/api/export/detailed-problems')
def export_detailed_problems():
    """Export problems with time range filtering"""
    print("\n" + "="*80)
    print("CSV EXPORT REQUEST")
    print("="*80)
    
    try:
        # Get time range parameters
        time_range = request.args.get('range', 'all')
        start_timestamp = request.args.get('start', type=int)
        end_timestamp = request.args.get('end', type=int)
        
        print(f"Parameters:")
        print(f"  Range: {time_range}")
        if start_timestamp:
            print(f"  Start: {datetime.fromtimestamp(start_timestamp).strftime('%Y-%m-%d %H:%M:%S')}")
        if end_timestamp:
            print(f"  End: {datetime.fromtimestamp(end_timestamp).strftime('%Y-%m-%d %H:%M:%S')}")
        
        # Generate report with time filtering
        if start_timestamp and end_timestamp:
            all_problems = generate_problem_report(
                time_range='custom',
                start_time=start_timestamp,
                end_time=end_timestamp
            )
        else:
            all_problems = generate_problem_report(time_range=time_range)
        
        print(f"\nProblems to export: {len(all_problems)}")
        
        if len(all_problems) == 0:
            csv_content = "Location,Hostgroup,Hostname,Problem,Severity,Created Time,Resolved Time\n"
            csv_content += "# No problems found in selected time range\n"
        else:
            severity_map = {
                0: 'Not Classified',
                1: 'Information',
                2: 'Warning',
                3: 'Average',
                4: 'High',
                5: 'Disaster'
            }
            
            csv_lines = []
            csv_lines.append("Location,Hostgroup,Hostname,Problem,Severity,Created Time,Resolved Time")
            
            for p in all_problems:
                csv_lines.append(
                    f'"{p["location"]}",'
                    f'"{p["hostgroup"]}",'
                    f'"{p["hostname"]}",'
                    f'"{p["problem"]}",'
                    f'"{severity_map.get(p["severity"], "Unknown")}",'
                    f'"{p["created_time"]}",'
                    f'"{p["resolved_time"]}"'
                )
            
            csv_content = '\n'.join(csv_lines)
        
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        if time_range == 'custom' and start_timestamp:
            start_date = datetime.fromtimestamp(start_timestamp).strftime('%Y%m%d')
            end_date = datetime.fromtimestamp(end_timestamp).strftime('%Y%m%d')
            filename = f'zabbix_problems_{start_date}_to_{end_date}_{timestamp}.csv'
        elif time_range != 'all':
            filename = f'zabbix_problems_{time_range}_{timestamp}.csv'
        else:
            filename = f'zabbix_active_problems_{timestamp}.csv'
        
        print(f"\nExport complete:")
        print(f"  Filename: {filename}")
        print(f"  Rows: {len(all_problems)}")
        print("="*80 + "\n")
        
        return Response(
            csv_content,
            mimetype='text/csv',
            headers={
                'Content-Disposition': f'attachment; filename={filename}',
                'Content-Type': 'text/csv; charset=utf-8'
            }
        )
        
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        print("="*80 + "\n")
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/all-hostgroups')
def get_all_hostgroups():
    """Get all hostgroups from all locations"""
    try:
        all_hostgroups = []
        
        for location_name, config in ZABBIX_LOCATIONS.items():
            try:
                zabbix = ZabbixAPI(
                    url=config['url'],
                    location=location_name,
                    token=config.get('token'),
                    username=config.get('username'),
                    password=config.get('password')
                )
                zabbix.authenticate()
                
                params = {
                    "output": ["groupid", "name"],
                    "sortfield": "name"
                }
                hostgroups = zabbix.make_request("hostgroup.get", params)
                
                for hg in hostgroups:
                    all_hostgroups.append({
                        'location': location_name,
                        'groupid': hg['groupid'],
                        'name': hg['name']
                    })
                
            except Exception as e:
                print(f"Error fetching hostgroups from {location_name}: {str(e)}")
        
        return jsonify({
            'success': True,
            'hostgroups': all_hostgroups
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/api/schedules/<int:schedule_id>/next-run', methods=['GET'])
def get_schedule_next_run(schedule_id):
    """Get next scheduled run time for a schedule"""
    try:
        schedules = load_schedules()
        schedule = next((s for s in schedules if s['id'] == schedule_id), None)
        
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404
        
        if not schedule.get('active'):
            return jsonify({'success': True, 'next_run': None, 'message': 'Schedule is inactive'})
        
        # Calculate next run time
        next_run = get_next_run_time(schedule)
        
        return jsonify({
            'success': True,
            'next_run': next_run.isoformat(),
            'next_run_formatted': next_run.strftime('%B %d, %Y at %I:%M %p')
        })
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/schedules/all-next-runs', methods=['GET'])
def get_all_next_runs():
    """Get next run times for all active schedules"""
    try:
        schedules = load_schedules()
        next_runs = {}
        
        for schedule in schedules:
            if schedule.get('active'):
                try:
                    next_run = get_next_run_time(schedule)
                    next_runs[schedule['id']] = {
                        'next_run': next_run.isoformat(),
                        'next_run_formatted': next_run.strftime('%B %d, %Y at %I:%M %p')
                    }
                except Exception as e:
                    print(f"Error calculating next run for schedule {schedule['id']}: {str(e)}")
                    next_runs[schedule['id']] = None
            else:
                next_runs[schedule['id']] = None
        
        return jsonify({'success': True, 'next_runs': next_runs})
        
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500
@app.route('/api/schedules/<int:schedule_id>/force-run', methods=['POST'])
def force_run_schedule(schedule_id):
    """Force run a schedule immediately regardless of schedule time"""
    try:
        schedules = load_schedules()
        schedule = next((s for s in schedules if s['id'] == schedule_id), None)
        
        if not schedule:
            return jsonify({'success': False, 'error': 'Schedule not found'}), 404
        
        print(f"\n{'='*80}")
        print(f"🚀 FORCE RUN TRIGGERED")
        print(f"  Schedule: {schedule['name']}")
        print(f"  Triggered at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"{'='*80}\n")
        
        # Execute the report
        result = execute_scheduled_report(schedule_id)
        
        if result:
            return jsonify({
                'success': True,
                'message': 'Schedule executed successfully',
                'recipients': schedule['recipients'],
                'total_problems': result.get('total_problems', 0)
            })
        else:
            return jsonify({
                'success': False,
                'error': 'Failed to execute schedule'
            }), 500
        
    except Exception as e:
        print(f"✗ Error in force run: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'error': str(e)}), 500

@app.route('/availability/host')
def host_details_page():
    """Host details page with graphs"""
    return render_template('host_details.html')






import json
import os







# ============================================================================
# LOCATION MANAGEMENT - KEEP ONLY THIS VERSION
# ============================================================================

def save_locations_config():
    """Save locations to a configuration file"""
    try:
        config_file = 'locations_config.json'
        
        config_data = {}
        for name, config in ZABBIX_LOCATIONS.items():
            config_data[name] = {
                'url': config.get('url', ''),
                'username': config.get('username', ''),
                'password': config.get('password', ''),
                'region': config.get('region', 'Unknown'),
                'description': config.get('description', ''),
                'token': config.get('token', None)
            }
        
        with open(config_file, 'w') as f:
            json.dump(config_data, f, indent=4)
        
        print(f"✓ Locations saved to {config_file}")
        return True
        
    except Exception as e:
        print(f"✗ Error saving config: {str(e)}")
        return False



# ============================================================================
# LOCATION MANAGEMENT ROUTES - FINAL CLEAN VERSION
# ============================================================================

@app.route('/locations')
def locations_page():
    """Locations management page"""
    return render_template('locations.html')


@app.route('/api/locations-summary')
def locations_summary():
    """Get summary of all locations with URL, username, region"""
    print("="*80)
    print("LOCATIONS SUMMARY REQUEST")
    print("="*80)
    
    locations_data = []
    global_stats = {
        'total_hosts': 0,
        'warning': 0,
        'critical': 0,
        'problem_hosts': 0
    }
    
    for location_name, config in ZABBIX_LOCATIONS.items():
        print(f"\n{location_name}")
        
        try:
            zabbix = ZabbixAPI(
                url=config['url'],
                location=location_name,
                token=config.get('token')
            )
            
            if 'username' in config and 'password' in config:
                zabbix.username = config['username']
                zabbix.password = config['password']
            
            zabbix.authenticate()
            print(f"  ✓ Authenticated")
            
            hosts_data = zabbix.get_hosts_summary()
            problems_data = zabbix.get_problem_hosts_summary()
            
            location_data = {
                'location': location_name,
                'url': config.get('url', 'N/A'),
                'username': config.get('username', 'N/A'),
                'region': config.get('region', 'Unknown'),
                'description': config.get('description', ''),
                'success': True,
                'total_hosts': hosts_data['total'],
                'enabled_hosts': hosts_data['enabled'],
                'disabled_hosts': hosts_data['disabled'],
                'problem_hosts': problems_data['problem_hosts'],
                'total_problems': problems_data['total_problems'],
                'warning_count': problems_data['warning'],
                'critical_count': problems_data['critical']
            }
            
            locations_data.append(location_data)
            
            global_stats['total_hosts'] += hosts_data['total']
            global_stats['warning'] += problems_data['warning']
            global_stats['critical'] += problems_data['critical']
            global_stats['problem_hosts'] += problems_data['problem_hosts']
            
            print(f"✓ Success: {location_name}")
            
        except Exception as e:
            print(f"✗ Error for {location_name}: {str(e)}")
            
            locations_data.append({
                'location': location_name,
                'url': config.get('url', 'N/A'),
                'username': config.get('username', 'N/A'),
                'region': config.get('region', 'Unknown'),
                'description': config.get('description', ''),
                'success': False,
                'error': str(e),
                'total_hosts': 0,
                'problem_hosts': 0,
                'warning_count': 0,
                'critical_count': 0
            })
    
    print("="*80)
    
    return jsonify({
        'success': True,
        'locations': locations_data,
        'global_stats': global_stats,
        'timestamp': datetime.now().isoformat()
    })


@app.route('/api/locations/add', methods=['POST'])
def add_location():
    """Add a new location"""
    try:
        data = request.json
        
        location_name = data.get('name', '').strip()
        zabbix_url = data.get('url', '').strip()
        username = data.get('username', '').strip()
        password = data.get('password', '').strip()
        region = data.get('region', 'Unknown').strip()
        description = data.get('description', '').strip()
        
        if not location_name or not zabbix_url or not username or not password:
            return jsonify({
                'success': False,
                'error': 'Name, URL, Username, and Password are required'
            }), 400
        
        if location_name in ZABBIX_LOCATIONS:
            return jsonify({
                'success': False,
                'error': f'Location "{location_name}" already exists'
            }), 400
        
        print(f"✓ Adding location: {location_name}")
        
        # Test connection
        try:
            test_zabbix = ZabbixAPI(url=zabbix_url, location=location_name, token=None)
            test_zabbix.username = username
            test_zabbix.password = password
            test_zabbix.authenticate()
            print("✓ Connection test successful!")
        except Exception as e:
            return jsonify({
                'success': False,
                'error': f'Failed to connect to Zabbix: {str(e)}'
            }), 400
        
        # Add to locations
        ZABBIX_LOCATIONS[location_name] = {
            'url': zabbix_url,
            'username': username,
            'password': password,
            'region': region,
            'description': description
        }
        
        # Save to config file
        save_locations_config()
        
        return jsonify({
            'success': True,
            'message': f'Location "{location_name}" added successfully'
        })
        
    except Exception as e:
        print(f"✗ Error adding location: {str(e)}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/api/locations/<location_name>', methods=['PUT', 'DELETE'])
def manage_location(location_name):
    """Update or delete a location"""
    
    if request.method == 'PUT':
        try:
            data = request.json
            
            if location_name not in ZABBIX_LOCATIONS:
                return jsonify({'success': False, 'error': 'Location not found'}), 404
            
            ZABBIX_LOCATIONS[location_name].update({
                'url': data.get('url'),
                'username': data.get('username'),
                'password': data.get('password'),
                'region': data.get('region', 'Unknown'),
                'description': data.get('description', '')
            })
            
            save_locations_config()
            
            return jsonify({
                'success': True,
                'message': f'Location "{location_name}" updated successfully'
            })
            
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500
    
    elif request.method == 'DELETE':
        try:
            if location_name not in ZABBIX_LOCATIONS:
                return jsonify({'success': False, 'error': 'Location not found'}), 404
            
            del ZABBIX_LOCATIONS[location_name]
            save_locations_config()
            
            return jsonify({
                'success': True,
                'message': f'Location "{location_name}" deleted successfully'
            })
            
        except Exception as e:
            return jsonify({'success': False, 'error': str(e)}), 500


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def save_locations_config():
    """Save locations to JSON file"""
    try:
        config_file = 'locations_config.json'
        config_data = {}
        
        for name, config in ZABBIX_LOCATIONS.items():
            config_data[name] = {
                'url': config.get('url', ''),
                'username': config.get('username', ''),
                'password': config.get('password', ''),
                'region': config.get('region', 'Unknown'),
                'description': config.get('description', ''),
                'token': config.get('token', None)
            }
        
        with open(config_file, 'w') as f:
            json.dump(config_data, f, indent=4)
        
        print(f"✓ Locations saved to {config_file}")
        return True
        
    except Exception as e:
        print(f"✗ Error saving config: {str(e)}")
        return False


def load_locations_config():
    """Load locations from JSON file"""
    try:
        config_file = 'locations_config.json'
        
        if not os.path.exists(config_file):
            print("⚠ No config file found, using default locations")
            return
        
        with open(config_file, 'r') as f:
            config_data = json.load(f)
        
        ZABBIX_LOCATIONS.clear()
        
        for name, config in config_data.items():
            ZABBIX_LOCATIONS[name] = {
                'url': config.get('url', ''),
                'username': config.get('username', ''),
                'password': config.get('password', ''),
                'region': config.get('region', 'Unknown'),
                'description': config.get('description', ''),
                'token': config.get('token', None)
            }
        
        print(f"✓ Loaded {len(config_data)} locations")
        for location in ZABBIX_LOCATIONS.keys():
            print(f"  • {location}")
        
    except Exception as e:
        print(f"✗ Error loading config: {str(e)}")


# ============================================================================
# STARTUP
# ============================================================================

if __name__ == '__main__':
    print("="*80)
    print("Zabbix Multi-Location Dashboard")
    print("="*80)
    
    # Load locations config
    load_locations_config()
    
    print(f"\n✓ Monitoring {len(ZABBIX_LOCATIONS)} locations")
    for loc in ZABBIX_LOCATIONS.keys():
        print(f"  • {loc}")
    
    # Initialize schedules
    init_schedules()
    
    print("\n✓ Dashboard: http://localhost:5000")
    print("✓ Locations: http://localhost:5000/locations")
    print("="*80 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)

